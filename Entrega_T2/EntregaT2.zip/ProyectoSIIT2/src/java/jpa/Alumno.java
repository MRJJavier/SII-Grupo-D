package jpa;



import java.io.Serializable;
import java.util.*;
import javax.persistence.*;

@Entity
@DiscriminatorValue(value="A")
public class Alumno extends Usuario implements Serializable{
    
    private String Curso;
    
    private String Carrera;
    
    private String Intereses;

   
    public Alumno(String dni, String nombre, String apellidos, String email, String contrasenia){
        super(dni, nombre, apellidos, email, contrasenia);
        
        
    }
    
    public Alumno(String dni, String nombre, String apellidos, String email, String contrasenia , String Curso, String Carrera, String Intereses) {
       super(dni,nombre, apellidos, email,contrasenia);
       this.Curso = Curso;
       this.Carrera = Carrera;
       this.Intereses = Intereses;
    }

    
    
    // getters y setters
    
    public String getCurso() {
        return Curso;
    }

    public void setCurso(String curso) {
        Curso = curso;
    }

    public String getCarrera() {
        return Carrera;
    }

    public void setCarrera(String carrera) {
        Carrera = carrera;
    }

    public String getIntereses() {
        return Intereses;
    }

    public void setIntereses(String intereses) {
        Intereses = intereses;
    }

   
    //hashcode y equals
    @Override
    public int hashCode() {
        int hash = 7;
        hash = 67 * hash + Objects.hashCode(this.Curso);
        hash = 67 * hash + Objects.hashCode(this.Carrera);
        hash = 67 * hash + Objects.hashCode(this.Intereses);
        return hash;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        final Alumno other = (Alumno) obj;
        if (!Objects.equals(this.Curso, other.Curso)) {
            return false;
        }
        if (!Objects.equals(this.Carrera, other.Carrera)) {
            return false;
        }
        if (!Objects.equals(this.Intereses, other.Intereses)) {
            return false;
        }
        return true;
    }
    
    
}