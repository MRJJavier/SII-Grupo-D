package backingBeans;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

import jpa.ONG;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Objects;
import javax.enterprise.context.SessionScoped;
import javax.inject.Inject;
import javax.inject.Named;

/**
 *
 * @author thejf
 */

@Named(value = "PerfilONG")
@SessionScoped
public class PerfilONG implements Serializable{
    
    @Inject
    private PasoDeONG pasaONG;
    
    private String nombre;
    private String desc;
    private String carac;
    private String NIF;
    private String dir;
    private int CP;
    private String loc;
    private int tel;
    private String email;
        
    private ArrayList<ONG> listaONGs
            = new ArrayList<ONG>(Arrays.asList(
                    new ONG("G-84451087", "UNICEF", "C/ Mauricio Legendre Nº36", 28046, "Madrid", 913789555, "info@unicef.es", 
                            "Organizacion dedicada a salvar el hambre de los niños", "Trabaja con niños. Diversidad social y voluntariados divertidos"),
                    new ONG("Q2866001", "Cruz Roja", "C/ Av. Reina Victoria 26-28", 28003, "Madrid", 952222222, "info@cre.org", 
                           "Movimiento humanitario mundial, colaborador del estado español y sus distintas nacionalidades en su labor humanitaria.",
                           "Siempre velará por su salud")
            ));

    public PerfilONG() {
    }

    public PasoDeONG getPasaONG() {
        return pasaONG;
    }

    public void setPasaONG(PasoDeONG pasaONG) {
        this.pasaONG = pasaONG;
    }

    public ArrayList<ONG> getListaONGs() {
        return listaONGs;
    }

    public void setListaONGs(ArrayList<ONG> listaONGs) {
        this.listaONGs = listaONGs;
    }
     
    
    public String removeONG(ONG res){
         listaONGs.remove(res);
         return "listaONGs";
    }

    public ArrayList<ONG> getONGs() {
        return listaONGs;
    }
    
    public String showONG(ONG res) {
        
        pasaONG.setOngPass(res);
        
        return "ONG.xhtml";
    }
    
    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getDesc() {
        return desc;
    }

    public void setDesc(String desc) {
        this.desc = desc;
    }

    public String getCarac() {
        return carac;
    }

    public void setCarac(String carac) {
        this.carac = carac;
    }
    
    public String getNIF() {
        return NIF;
    }

    public void setNIF(String NIF) {
        this.NIF = NIF;
    }   

    public String getDir() {
        return dir;
    }

    public void setDir(String Direccion) {
        dir = Direccion;
    }

    public int getCP() {
        return CP;
    }

    public void setCP(int cp) {
        CP = cp;
    }

    public String getLoc() {
        return loc;
    }

    public void setLoc(String localidad) {
        loc = localidad;
    }

    public int getTel() {
        return tel;
    }

    public void setTel(int tlf) {
        tel= tlf;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    @Override
    public int hashCode() {
        int hash = 5;
        hash = 97 * hash + Objects.hashCode(this.pasaONG);
        hash = 97 * hash + Objects.hashCode(this.nombre);
        hash = 97 * hash + Objects.hashCode(this.desc);
        hash = 97 * hash + Objects.hashCode(this.carac);
        hash = 97 * hash + Objects.hashCode(this.NIF);
        hash = 97 * hash + Objects.hashCode(this.dir);
        hash = 97 * hash + this.CP;
        hash = 97 * hash + Objects.hashCode(this.loc);
        hash = 97 * hash + this.tel;
        hash = 97 * hash + Objects.hashCode(this.email);
        hash = 97 * hash + Objects.hashCode(this.listaONGs);
        return hash;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        final PerfilONG other = (PerfilONG) obj;
        if (this.CP != other.CP) {
            return false;
        }
        if (this.tel != other.tel) {
            return false;
        }
        if (!Objects.equals(this.nombre, other.nombre)) {
            return false;
        }
        if (!Objects.equals(this.desc, other.desc)) {
            return false;
        }
        if (!Objects.equals(this.carac, other.carac)) {
            return false;
        }
        if (!Objects.equals(this.NIF, other.NIF)) {
            return false;
        }
        if (!Objects.equals(this.dir, other.dir)) {
            return false;
        }
        if (!Objects.equals(this.loc, other.loc)) {
            return false;
        }
        if (!Objects.equals(this.email, other.email)) {
            return false;
        }
        if (!Objects.equals(this.pasaONG, other.pasaONG)) {
            return false;
        }
        if (!Objects.equals(this.listaONGs, other.listaONGs)) {
            return false;
        }
        return true;
    }
    
    
    
}
