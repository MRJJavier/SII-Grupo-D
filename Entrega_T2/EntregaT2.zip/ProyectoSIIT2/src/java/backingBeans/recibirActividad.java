package backingBeans;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
import jpa.Actividad;
import java.io.Serializable;
import java.util.Objects;
import javax.enterprise.context.SessionScoped;
import javax.inject.Named;
import jpa.Formativa;

/**
 *
 * @author sergi
 */
@Named
@SessionScoped
public class recibirActividad implements Serializable {

    private Actividad actividad;

    public recibirActividad() {
    }

    public Actividad getActividad() {
        return actividad;
    }
    
    public void setActividad(Actividad actividad) {
        this.actividad = actividad;
    }

    public Formativa getFormativa() {
        Formativa form = (Formativa) actividad;
        return form;
    }

    @Override
    public int hashCode() {
        int hash = 7;
        hash = 67 * hash + Objects.hashCode(this.actividad);
        return hash;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        final recibirActividad other = (recibirActividad) obj;
        if (!Objects.equals(this.actividad, other.actividad)) {
            return false;
        }
        return true;
    }
    
    

}
