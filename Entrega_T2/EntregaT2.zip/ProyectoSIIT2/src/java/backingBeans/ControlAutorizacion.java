package backingBeans;

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

import jpa.Actividad;
import javax.inject.Named;
import javax.enterprise.context.SessionScoped;
import java.io.Serializable;
import java.util.List;
import java.util.Objects;
import javax.faces.context.FacesContext;
import jpa.Usuario;

/**
 *
 * @author francis
 */
@Named(value = "controlAutorizacion")
@SessionScoped
public class ControlAutorizacion implements Serializable {

    private Object entidad;
    
   

    public void setEntidad(Object entidad) {
        this.entidad = entidad;
    }

    public Object getEntidad() {
        return entidad;
    }
    
    public List<Actividad> getMisAct(){
        Usuario res = (Usuario) entidad;
        return res.getParticipaEnAct();
                
    }
    


    
    public String logout()
    {
        // Destruye la sesión (y con ello, el ámbito de este bean)
        FacesContext ctx = FacesContext.getCurrentInstance();
        ctx.getExternalContext().invalidateSession();
        entidad = null;
        return "login";
    }

    /**
     * Creates a new instance of ControlAutorizacion
     */
    public ControlAutorizacion() {
    }

    @Override
    public int hashCode() {
        int hash = 3;
        hash = 53 * hash + Objects.hashCode(this.entidad);
        return hash;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        final ControlAutorizacion other = (ControlAutorizacion) obj;
        if (!Objects.equals(this.entidad, other.entidad)) {
            return false;
        }
        return true;
    }
    
    
    
}
