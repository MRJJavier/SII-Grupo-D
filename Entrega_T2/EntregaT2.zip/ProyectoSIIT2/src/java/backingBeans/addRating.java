package backingBeans;

import jpa.Usuario;
import jpa.ONG;
import jpa.Actividad;
import jpa.Informe;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;
import javax.enterprise.context.SessionScoped;
import javax.inject.Inject;
import javax.inject.Named;

@Named
@SessionScoped
//No deberia de ser session, deberiamos sacar el el informe fuera y cambiar esta por RequestScoped
public class addRating implements Serializable {

    @Inject
    private ControlAutorizacion ctrl;

    private ONG ong;
    private Actividad act;
    private String mensaje;
    private String punta;
    private String puntu;
    private static Long num = 1L;
    private static ArrayList<Informe> informes = new ArrayList<>();

    public addRating() {
    }

    public ONG getOngObject() {
        return ong;
    }
    
    public Actividad getActividad() {
        return act;
    }

    public void setAct(Actividad act) {
        this.act = act;
    }

    public void setOng(ONG ong) {
        this.ong = ong;
    }
    
    
    public ControlAutorizacion getCtrl() {
        return ctrl;
    }

    public void setCtrl(ControlAutorizacion ctrl) {
        this.ctrl = ctrl;
    }

    public static Long getNum() {
        return num;
    }

    public static void setNum(Long num) {
        addRating.num = num;
    }

    public String enviarmsg() {
        Usuario user = (Usuario) ctrl.getEntidad();
        Informe inf = new Informe(num, mensaje, puntu, punta, user, act);

        informes.add(inf);
        List<Actividad> susAct = user.getParticipaEnAct();
        susAct.remove(act);
        user.setActCoordinadas(susAct);
        num++;

        return "dashboard";
    }

    public static ArrayList<Informe> getInformes() {
        return informes;
    }

    public static void setInformes(ArrayList<Informe> informes) {
        addRating.informes = informes;
    }

    public String gotoValora(Actividad res) {
        act = res;
        System.out.println("" + act.getNIFONG().getNombreOrg() + act.getNombreActividad());
        ong = res.getNIFONG();
        return "puntuarActividad";
    }

    public String getOng() {
        return ong.getNombreOrg();
    }
    
    public String getAct() {
        return act.getNombreActividad();
    }

    public String getMensaje() {
        return mensaje;
    }

    public void setMensaje(String mensaje) {
        this.mensaje = mensaje;
    }

    public String getPunta() {
        return punta;
    }

    public void setPunta(String punta) {
        this.punta = punta;
    }

    public String getPuntu() {
        return puntu;
    }

    public void setPuntu(String puntu) {
        this.puntu = puntu;
    }

    @Override
    public int hashCode() {
        int hash = 3;
        hash = 47 * hash + Objects.hashCode(this.ctrl);
        hash = 47 * hash + Objects.hashCode(this.ong);
        hash = 47 * hash + Objects.hashCode(this.act);
        hash = 47 * hash + Objects.hashCode(this.mensaje);
        hash = 47 * hash + Objects.hashCode(this.punta);
        hash = 47 * hash + Objects.hashCode(this.puntu);
        return hash;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        final addRating other = (addRating) obj;
        if (!Objects.equals(this.mensaje, other.mensaje)) {
            return false;
        }
        if (!Objects.equals(this.punta, other.punta)) {
            return false;
        }
        if (!Objects.equals(this.puntu, other.puntu)) {
            return false;
        }
        if (!Objects.equals(this.ctrl, other.ctrl)) {
            return false;
        }
        if (!Objects.equals(this.ong, other.ong)) {
            return false;
        }
        if (!Objects.equals(this.act, other.act)) {
            return false;
        }
        return true;
    }
    
    

}
