package backingBeans;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */


import jpa.Usuario;
import jpa.Alumno;
import jpa.Profesor;
import java.util.Date;
import java.util.Objects;
import javax.enterprise.context.RequestScoped;
import javax.inject.Inject;
import javax.inject.Named;

/**
 *
 * @author mrjjavier
 */
@Named(value = "editprofile")
@RequestScoped
public class EditProfile {

    @Inject
    private ControlAutorizacion ctrl;


    private Date fechaNacimiento;
    private String competencias;
    private String profesion;
    private String telefono;
    private String direccion;
    private String disponibilidad;
    private String curso;
    private String carrera;
    private String intereses;
    private String ramaEstudio;
    
    public EditProfile() {
        
    }
    
    
    
    //Guarda los cambios realizados en el perfil

    public String guardarCambios(){
        Object obj = ctrl.getEntidad();
        
        
       
        if(obj instanceof Usuario){
            Usuario usr = (Usuario) obj;
            usr.setFechaNacimiento(fechaNacimiento);
            usr.setCompetencias(competencias);
            usr.setProfesion(profesion);
            usr.setTelefono(telefono);
            usr.setDireccion(direccion);
            usr.setDisponibilidad(disponibilidad);

            ctrl.setEntidad(usr);
            
            //ctrl.setEntidad((Object) usr);

        }else if(obj instanceof Profesor){
            Profesor prof = (Profesor) obj;
            prof.setFechaNacimiento(fechaNacimiento);
            prof.setCompetencias(competencias);
            prof.setProfesion(profesion);
            prof.setTelefono(telefono);
            prof.setDireccion(direccion);
            prof.setDisponibilidad(disponibilidad);

            prof.setRamaEstudio(ramaEstudio);

            ctrl.setEntidad(prof);
            //ctrl.setEntidad((Object) prof);

        }else{
            Alumno alu = (Alumno) obj;
            alu.setFechaNacimiento(fechaNacimiento);
            alu.setCompetencias(competencias);
            alu.setProfesion(profesion);
            alu.setTelefono(telefono);
            alu.setDireccion(direccion);
            alu.setDisponibilidad(disponibilidad);

            alu.setCurso(curso);
            alu.setCarrera(carrera);
            alu.setIntereses(intereses);

            ctrl.setEntidad(alu);
            //ctrl.setEntidad((Object) alu);
        }

        return "profile.xhtml";
    }


    //Getters y setters

    public ControlAutorizacion getCtrl() {
        return ctrl;
    }

    public void setCtrl(ControlAutorizacion ctrl) {
        this.ctrl = ctrl;
    }

    public Date getFechaNacimiento() {
        return fechaNacimiento;
    }

    public void setFechaNacimiento(Date fechaNacimiento) {
        this.fechaNacimiento = fechaNacimiento;
    }

    public String getCompetencias() {
        return competencias;
    }

    public void setCompetencias(String competencias) {
        this.competencias = competencias;
    }

    public String getProfesion() {
        return profesion;
    }

    public void setProfesion(String profesion) {
        this.profesion = profesion;
    }

    public String getTelefono() {
        return telefono;
    }

    public void setTelefono(String telefono) {
        this.telefono = telefono;
    }

    public String getDireccion() {
        return direccion;
    }

    public void setDireccion(String direccion) {
        this.direccion = direccion;
    }

    public String getDisponibilidad() {
        return disponibilidad;
    }

    public void setDisponibilidad(String disponibilidad) {
        this.disponibilidad = disponibilidad;
    }

    public String getCurso() {
        return curso;
    }

    public void setCurso(String curso) {
        this.curso = curso;
    }

    public String getCarrera() {
        return carrera;
    }

    public void setCarrera(String carrera) {
        this.carrera = carrera;
    }

    public String getIntereses() {
        return intereses;
    }

    public void setIntereses(String intereses) {
        this.intereses = intereses;
    }

    public String getRamaEstudio() {
        return ramaEstudio;
    }

    public void setRamaEstudio(String ramaEstudio) {
        this.ramaEstudio = ramaEstudio;
    }

    @Override
    public int hashCode() {
        int hash = 5;
        hash = 67 * hash + Objects.hashCode(this.ctrl);
        hash = 67 * hash + Objects.hashCode(this.fechaNacimiento);
        hash = 67 * hash + Objects.hashCode(this.competencias);
        hash = 67 * hash + Objects.hashCode(this.profesion);
        hash = 67 * hash + Objects.hashCode(this.telefono);
        hash = 67 * hash + Objects.hashCode(this.direccion);
        hash = 67 * hash + Objects.hashCode(this.disponibilidad);
        hash = 67 * hash + Objects.hashCode(this.curso);
        hash = 67 * hash + Objects.hashCode(this.carrera);
        hash = 67 * hash + Objects.hashCode(this.intereses);
        hash = 67 * hash + Objects.hashCode(this.ramaEstudio);
        return hash;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        final EditProfile other = (EditProfile) obj;
        if (!Objects.equals(this.competencias, other.competencias)) {
            return false;
        }
        if (!Objects.equals(this.profesion, other.profesion)) {
            return false;
        }
        if (!Objects.equals(this.telefono, other.telefono)) {
            return false;
        }
        if (!Objects.equals(this.direccion, other.direccion)) {
            return false;
        }
        if (!Objects.equals(this.disponibilidad, other.disponibilidad)) {
            return false;
        }
        if (!Objects.equals(this.curso, other.curso)) {
            return false;
        }
        if (!Objects.equals(this.carrera, other.carrera)) {
            return false;
        }
        if (!Objects.equals(this.intereses, other.intereses)) {
            return false;
        }
        if (!Objects.equals(this.ramaEstudio, other.ramaEstudio)) {
            return false;
        }
        if (!Objects.equals(this.ctrl, other.ctrl)) {
            return false;
        }
        if (!Objects.equals(this.fechaNacimiento, other.fechaNacimiento)) {
            return false;
        }
        return true;
    }

    
    
    
    
}
