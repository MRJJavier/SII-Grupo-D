package backingBeans;

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
import jpa.Usuario;
import jpa.Alumno;
import jpa.Actividad;
import jpa.Profesor;
import jpa.SolicitudEntrada;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Objects;
import javax.inject.Named;
import javax.enterprise.context.SessionScoped;
import javax.faces.application.FacesMessage;
import javax.faces.context.FacesContext;
import javax.inject.Inject;
import jpa.ONG;

/**
 *
 * @author francis
 */
@Named(value = "login")
@SessionScoped
public class Login implements Serializable {

    private String email;
    private String contrasenia;
    /*Atributos para registro */
    private String nombrereg;
    private String apellidosreg;
    private String emailreg;
    private String DNIreg;
    private String passreg;
    private String repPassreg;
    /*------------------------*/

    @Inject
    private ControlAutorizacion ctrl;
    private static List<Object> obj_usr = new ArrayList<>(Arrays.asList(
            new Usuario("talfDNI", "Talftulistas", "Unidos", "talfUnited@uma.es", "talf"),
            new Alumno("antonioDNI", "Antonio Jesús", "Chaves Garcia", "antoniochavesgarcia@uma.es", "pw", "Tercero", "Ing. Informática", "Ver a ElMiilloR"),
            new Profesor("amozoDNI", "Alejandro Jesús", "Mozo", "amozo@uma.es", "amozo", "Inteligencia Computacional y Análisis de Imágenes")
    ));

    /**
     * Creates a new instance of Login
     */
    public Login() {

    }

    public ControlAutorizacion getCtrl() {
        return ctrl;
    }

    public void setCtrl(ControlAutorizacion ctrl) {
        this.ctrl = ctrl;
    }

    public static List<Object> getObj_usr() {
        return obj_usr;
    }

    public static void setObj_usr(List<Object> obj_usr) {
        Login.obj_usr = obj_usr;
    }
    
    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getNombrereg() {
        return nombrereg;
    }

    public void setNombrereg(String nombrereg) {
        this.nombrereg = nombrereg;
    }

    public String getApellidosreg() {
        return apellidosreg;
    }

    public void setApellidosreg(String apellidosreg) {
        this.apellidosreg = apellidosreg;
    }

    public String getEmailreg() {
        return emailreg;
    }

    public void setEmailreg(String emailreg) {
        this.emailreg = emailreg;
    }

    public String getDNIreg() {
        return DNIreg;
    }

    public void setDNIreg(String DNIreg) {
        this.DNIreg = DNIreg;
    }

    public String getPassreg() {
        return passreg;
    }

    public void setPassreg(String passreg) {
        this.passreg = passreg;
    }

    public String getRepPassreg() {
        return repPassreg;
    }

    public void setRepPassreg(String repPassreg) {
        this.repPassreg = repPassreg;
    }

    public String getContrasenia() {
        return contrasenia;
    }

    public void setUsuario(String usuario) {
        this.email = usuario;
    }

    public void setContrasenia(String contrasenia) {
        this.contrasenia = contrasenia;
    }

    public String autenticar() {
        FacesContext ctx = FacesContext.getCurrentInstance();
        if (this.email.equals("") || this.contrasenia.equals("")) {
            ctx.addMessage(null, new FacesMessage(FacesMessage.SEVERITY_ERROR, "Error, no hay usuario o contraseña", "Error, no hay usuario o contraseña"));
            return null;
        } else {
            Object user = null;
            for (Object aux : this.obj_usr) {
                if (aux instanceof Profesor) {
                    Profesor res = (Profesor) aux;
                    if (res.getContrasenya().equals(this.contrasenia) && res.getEmail().equals(this.email)) {
                        user = res;
                        ctrl.setEntidad(user);
                        break;
                    }
                } else if (aux instanceof Alumno) {
                    Alumno res = (Alumno) aux;
                    if (res.getContrasenya().equals(this.contrasenia) && res.getEmail().equals(this.email)) {
                        user = res;
                        ctrl.setEntidad(user);
                        break;
                    }
                } else {
                    Usuario res = (Usuario) aux;
                    if (res.getContrasenya().equals(this.contrasenia) && res.getEmail().equals(this.email)) {
                        user = res;
                        ctrl.setEntidad(user);
                        break;
                    }
                }

            }
            if (user == null) {
                return "login";
            }
            return "dashboard";
        }
    }

    public String registrar() {
        FacesContext.getCurrentInstance();
        if (DNIreg.equals("") || apellidosreg.equals("") | nombrereg.equals("") | emailreg.equals("") | passreg.equals("")) {
            FacesMessage fm = new FacesMessage("Hay campos nulos");
            FacesContext.getCurrentInstance().addMessage("Sistema: ", fm);
            return null;
        }
        if (!this.passreg.equals(this.repPassreg)) {
            FacesMessage fm = new FacesMessage("Las contraseñas no coinciden");
            FacesContext.getCurrentInstance().addMessage("Sistema: ", fm);
            return null;
        }
        Alumno aux = new Alumno(DNIreg, nombrereg, apellidosreg, emailreg, passreg);
        for (Object a : obj_usr) {
            if (aux.equals(a)) {
                FacesMessage fm = new FacesMessage("Ya hay una cuenta así");
                FacesContext.getCurrentInstance().addMessage("Sistema: ", fm);
                return null;
            }
        }
        obj_usr.add(aux);
        return "login";
    }

    public void setActividad(SolicitudEntrada soli) {
        Integer aux = obj_usr.indexOf(soli.getCodUsuario());

        List<Actividad> laux = soli.getCodUsuario().getParticipaEnAct();
        laux.add(soli.getCodActividad());
        Usuario usr = soli.getCodUsuario();
        usr.setParticipaEnAct(laux);
        obj_usr.remove(aux);
        obj_usr.add(usr);
    }

    public void quitarDeActividad(Actividad act) {
        List<Actividad> laux;
        for (Object o : obj_usr) {
            laux = ((Usuario) o).getParticipaEnAct();
            laux.remove(act);
            ((Usuario) o).setParticipaEnAct(laux);
        }
    }

    @Override
    public int hashCode() {
        int hash = 5;
        hash = 53 * hash + Objects.hashCode(this.email);
        hash = 53 * hash + Objects.hashCode(this.contrasenia);
        hash = 53 * hash + Objects.hashCode(this.nombrereg);
        hash = 53 * hash + Objects.hashCode(this.apellidosreg);
        hash = 53 * hash + Objects.hashCode(this.emailreg);
        hash = 53 * hash + Objects.hashCode(this.DNIreg);
        hash = 53 * hash + Objects.hashCode(this.passreg);
        hash = 53 * hash + Objects.hashCode(this.repPassreg);
        hash = 53 * hash + Objects.hashCode(this.ctrl);
        return hash;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        final Login other = (Login) obj;
        if (!Objects.equals(this.email, other.email)) {
            return false;
        }
        if (!Objects.equals(this.contrasenia, other.contrasenia)) {
            return false;
        }
        if (!Objects.equals(this.nombrereg, other.nombrereg)) {
            return false;
        }
        if (!Objects.equals(this.apellidosreg, other.apellidosreg)) {
            return false;
        }
        if (!Objects.equals(this.emailreg, other.emailreg)) {
            return false;
        }
        if (!Objects.equals(this.DNIreg, other.DNIreg)) {
            return false;
        }
        if (!Objects.equals(this.passreg, other.passreg)) {
            return false;
        }
        if (!Objects.equals(this.repPassreg, other.repPassreg)) {
            return false;
        }
        if (!Objects.equals(this.ctrl, other.ctrl)) {
            return false;
        }
        return true;
    }
    
    

}
