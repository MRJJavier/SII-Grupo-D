package backingBeans;


import jpa.ONG;
import java.io.Serializable;
import java.util.Objects;
import javax.enterprise.context.SessionScoped;
import javax.inject.Named;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author ps3aj
 */
@Named(value = "pasoDeONG")
@SessionScoped
public class PasoDeONG implements Serializable{
    
    private ONG ongPass;

    public ONG getOngPass() {
        return ongPass;
    }

    public void setOngPass(ONG ongPass) {
        this.ongPass = ongPass;
    }

    public PasoDeONG() {
    }

    @Override
    public int hashCode() {
        int hash = 3;
        hash = 89 * hash + Objects.hashCode(this.ongPass);
        return hash;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        final PasoDeONG other = (PasoDeONG) obj;
        if (!Objects.equals(this.ongPass, other.ongPass)) {
            return false;
        }
        return true;
    }
    
    
    
    
    
}
