package backingBeans;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
import jpa.Usuario;
import jpa.ONG;
import jpa.Formativa;
import jpa.Actividad;
import jpa.Voluntariado;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Objects;
import javax.enterprise.context.RequestScoped;
import javax.inject.Inject;
import javax.inject.Named;

@Named
@RequestScoped
public class crearTarea implements Serializable {
    
    @Inject
    private recibirActividad pasitoApasito;
    
    @Inject
    private PerfilONG perfOng;
    
    @Inject
    private ControlAutorizacion control;
    
    @Inject
    private Login log;

    private Long codActividad;
    private String nombreActividad;
    private Integer numHoras;
    private String descripcionActividad;
    private String tipo;
    private String rama;
    private Integer creditos;
    private String org;
    
    // Se crean las ONGs aqui otra vez por el tema de que estamos declarando el los backing beans. Si estuvieramos ya con la base de datos y EJB, no habria problema.
    private static ArrayList<Actividad> actividades = new ArrayList<>(Arrays.asList(
            new Voluntariado(
                    1L, "Aprende danza clásica", 20, "Aprende el tradicional baile ghanés.", 2,
                    new ONG("G-84451087", "UNICEF", "C/ Mauricio Legendre Nº36", 28046, "Madrid", 913789555, "info@unicef.es",
                            "Organizacion dedicada a salvar el hambre de los niños", "Trabaja con niños. Diversidad social y voluntariados divertidos"), 
                    new Usuario("talfDNI", "Talftulistas", "Unidos", "talfUnited@uma.es", "talf")),
            new Formativa(
                    2L, "Aprende inglés en Botsuana", 60, "Inglés en África", "Idiomas",
                    new ONG("Q2866001", "Cruz Roja", "C/ Av. Reina Victoria 26-28", 28003, "Madrid", 952222222, "info@cre.org", 
                           "Movimiento humanitario mundial, colaborador del estado español y sus distintas nacionalidades en su labor humanitaria.",
                           "Siempre velará por su salud"), 
                    new Usuario("talfDNI", "Talftulistas", "Unidos", "talfUnited@uma.es", "talf"))
    ));

    public crearTarea() {
    }

    public recibirActividad getPasitoApasito() {
        return pasitoApasito;
    }

    public void setPasitoApasito(recibirActividad pasitoApasito) {
        this.pasitoApasito = pasitoApasito;
    }

    public PerfilONG getPerfOng() {
        return perfOng;
    }

    public void setPerfOng(PerfilONG perfOng) {
        this.perfOng = perfOng;
    }

    public ControlAutorizacion getControl() {
        return control;
    }

    public void setControl(ControlAutorizacion control) {
        this.control = control;
    }

    public Login getLog() {
        return log;
    }

    public void setLog(Login log) {
        this.log = log;
    }
    
// --    

    public String pasaActividad(Actividad activ) {
        pasitoApasito.setActividad(activ);
        return "actividad";
    }
    
    public String borrarAct(Actividad activ) {
      actividades.remove(activ);
      log.quitarDeActividad(activ);
      return "listaActividades";
   }

    public String getOrg() {
        return org;
    }

    public void setOrg(String org) {
        this.org = org;
    }

    public Integer getNumHoras() {

        return numHoras;
    }

    public void setNumHoras(String a) {
        this.numHoras = Integer.parseInt(a);
    }

    public Long getCodActividad() {
        return codActividad;
    }

    public String getNombreActividad() {
        return nombreActividad;
    }

    public String getDescripcionActividad() {
        return descripcionActividad;
    }

    public String getTipo() {
        return tipo;
    }

    public void setCodActividad(String codActividad) {
        this.codActividad = Long.parseLong(codActividad);
    }

    public void setNombreActividad(String nombreActividad) {
        this.nombreActividad = nombreActividad;
    }

    public void setDescripcionActividad(String descripcionActividad) {
        this.descripcionActividad = descripcionActividad;
    }

    public void setTipo(String tipo) {
        this.tipo = tipo;
    }

    public ArrayList<Actividad> getActividades() {
        return actividades;
    }

    public void setActividad(List<Actividad> Actividad2) {
        this.actividades.add((Actividad) Actividad2);
    }
//Para las ongs que tienen que estar pondremos un selector de todas las que hay.

    public String imp() {
        ONG aux = null;
        for(ONG o : perfOng.getONGs()){
            if(org.equals(o.getNombreOrg())) aux = o;
        }
        if (tipo.equals("V")) {
            Usuario usraux = (Usuario) control.getEntidad();
            Voluntariado vol = new Voluntariado(codActividad, nombreActividad, numHoras, descripcionActividad, creditos, aux, usraux);
            actividades.add(vol);
            
        } else if (tipo.equals("F")) {
            Usuario usraux = (Usuario) control.getEntidad();
            Formativa form = new Formativa(codActividad, nombreActividad, numHoras, descripcionActividad, rama, aux, usraux);
            actividades.add(form);

        }
       return "listaActividades"; 
    }

    public void setCodActividad(Long codActividad) {
        this.codActividad = codActividad;
    }

    public void setNumHoras(Integer numHoras) {
        this.numHoras = numHoras;
    }

    public static void setActividades(ArrayList<Actividad> actividades) {
        crearTarea.actividades = actividades;
    }

    public String getRama() {
        return rama;
    }

    public void setRama(String rama) {
        this.rama = rama;
    }

    public Integer getCreditos() {
        return creditos;
    }

    public void setCreditos(Integer creditos) {
        this.creditos = creditos;
    }

    @Override
    public int hashCode() {
        int hash = 7;
        hash = 59 * hash + Objects.hashCode(this.pasitoApasito);
        hash = 59 * hash + Objects.hashCode(this.perfOng);
        hash = 59 * hash + Objects.hashCode(this.control);
        hash = 59 * hash + Objects.hashCode(this.log);
        hash = 59 * hash + Objects.hashCode(this.codActividad);
        hash = 59 * hash + Objects.hashCode(this.nombreActividad);
        hash = 59 * hash + Objects.hashCode(this.numHoras);
        hash = 59 * hash + Objects.hashCode(this.descripcionActividad);
        hash = 59 * hash + Objects.hashCode(this.tipo);
        hash = 59 * hash + Objects.hashCode(this.rama);
        hash = 59 * hash + Objects.hashCode(this.creditos);
        hash = 59 * hash + Objects.hashCode(this.org);
        return hash;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        final crearTarea other = (crearTarea) obj;
        if (!Objects.equals(this.nombreActividad, other.nombreActividad)) {
            return false;
        }
        if (!Objects.equals(this.descripcionActividad, other.descripcionActividad)) {
            return false;
        }
        if (!Objects.equals(this.tipo, other.tipo)) {
            return false;
        }
        if (!Objects.equals(this.rama, other.rama)) {
            return false;
        }
        if (!Objects.equals(this.org, other.org)) {
            return false;
        }
        if (!Objects.equals(this.pasitoApasito, other.pasitoApasito)) {
            return false;
        }
        if (!Objects.equals(this.perfOng, other.perfOng)) {
            return false;
        }
        if (!Objects.equals(this.control, other.control)) {
            return false;
        }
        if (!Objects.equals(this.log, other.log)) {
            return false;
        }
        if (!Objects.equals(this.codActividad, other.codActividad)) {
            return false;
        }
        if (!Objects.equals(this.numHoras, other.numHoras)) {
            return false;
        }
        if (!Objects.equals(this.creditos, other.creditos)) {
            return false;
        }
        return true;
    }
    
    

}
