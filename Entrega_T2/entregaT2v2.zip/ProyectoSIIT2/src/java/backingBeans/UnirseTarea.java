package backingBeans;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
import jpa.Actividad;
import jpa.SolicitudEntrada;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Objects;
import javax.enterprise.context.RequestScoped;
import javax.inject.Inject;
import javax.inject.Named;
import jpa.Formativa;
import jpa.Profesor;
import jpa.Usuario;

@Named(value="unirseTarea")
@RequestScoped
public class UnirseTarea implements Serializable {

    @Inject
    private ControlAutorizacion control;
    
    @Inject
    private Login login;
    

    private static ArrayList<SolicitudEntrada> solicitudes = new ArrayList<>();
    private static Integer codigos = 1;

    public UnirseTarea() {

    }

    public Login getLogin() {
        return login;
    }

    public void setLogin(Login login) {
        this.login = login;
    }
    
    public ControlAutorizacion getControl() {
        return control;
    }

    public void setControl(ControlAutorizacion control) {
        this.control = control;
    }

    public static ArrayList<SolicitudEntrada> getSolicitudes() {
        return solicitudes;
    }

    public static void setSolicitudes(ArrayList<SolicitudEntrada> solicitudes) {
        UnirseTarea.solicitudes = solicitudes;
    }

    public static Integer getCodigos() {
        return codigos;
    }

    public static void setCodigos(Integer codigos) {
        UnirseTarea.codigos = codigos;
    }

    public String crearSolicitud(Actividad act) {
        SolicitudEntrada solicitud = new SolicitudEntrada();
        solicitud.setCodActividad(act);
        Object aux = control.getEntidad();
                    
        solicitud.setCodUsuario((Usuario)aux);
        solicitud.setCodigoSolicitud(codigos++);
        solicitud.setFechaDeSolicitud(new Date());
        solicitudes.add(solicitud);
        
        return "listaActividades";
       

    }
    
    public String aceptarSolicitud(SolicitudEntrada soli){
        List<Usuario> lisaux = soli.getCodActividad().getUsuarioPart();
        lisaux.add(soli.getCodUsuario());
        soli.getCodActividad().setUsuarioPart(lisaux);
        login.setActividad(soli);
        solicitudes.remove(soli);
        return "dashboard";
    }
    
    public String borrarSolicitud(SolicitudEntrada soli){
        solicitudes.remove(soli);
        login.quitarDeActividad(soli.getCodActividad());
        return "dashboard";
    }
    
    public String supervisaActividad(Formativa act){
        Profesor pr = (Profesor) control.getEntidad();
        List <Profesor> listaProfesores = act.getCoordProf();
        listaProfesores.add(pr);
        act.setCoordProf(listaProfesores);
                
        return "dashboard";
    }

    @Override
    public int hashCode() {
        int hash = 3;
        hash = 29 * hash + Objects.hashCode(this.control);
        hash = 29 * hash + Objects.hashCode(this.login);
        return hash;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        final UnirseTarea other = (UnirseTarea) obj;
        if (!Objects.equals(this.control, other.control)) {
            return false;
        }
        if (!Objects.equals(this.login, other.login)) {
            return false;
        }
        return true;
    }

    
    
}
