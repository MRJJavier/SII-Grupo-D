package backingBeans;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
import ejb.EJB_ActividadLocal;
import ejb.EJB_InformeLocal;
import ejb.EJB_SolicitudEntradaLocal;
import ejb.EJB_UsuarioLocal;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Objects;
import javax.ejb.EJB;
import javax.enterprise.context.RequestScoped;
import javax.inject.Inject;
import javax.inject.Named;
import jpa.Actividad;
import jpa.Alumno;
import jpa.Formativa;
import jpa.Informe;
import jpa.ONG;
import jpa.Profesor;
import jpa.SolicitudEntrada;
import jpa.Usuario;
import jpa.Voluntariado;

@Named
@RequestScoped
public class crearTarea implements Serializable {

    @Inject
    private recibirActividad pasitoApasito;

    @Inject
    private PerfilONG perfOng;

    @Inject
    private ControlAutorizacion control;

    @Inject
    private Login log;

    @EJB
    private EJB_ActividadLocal ejbACT;

    @EJB
    private EJB_UsuarioLocal ejbUSR;

    @EJB
    private EJB_InformeLocal ejbINF;
    
    
    @EJB
    private EJB_SolicitudEntradaLocal ejbSOL;

    private String nombreActividad;
    private Integer numHoras;
    private String descripcionActividad;
    private String tipo;
    private String rama;
    private Integer creditos;
    private String org;

    public crearTarea() {
    }

    public recibirActividad getPasitoApasito() {
        return pasitoApasito;
    }

    public void setPasitoApasito(recibirActividad pasitoApasito) {
        this.pasitoApasito = pasitoApasito;
    }

    public PerfilONG getPerfOng() {
        return perfOng;
    }

    public void setPerfOng(PerfilONG perfOng) {
        this.perfOng = perfOng;
    }

    public ControlAutorizacion getControl() {
        return control;
    }

    public void setControl(ControlAutorizacion control) {
        this.control = control;
    }

    public Login getLog() {
        return log;
    }

    public void setLog(Login log) {
        this.log = log;
    }

// --    
    public String pasaActividad(Actividad activ) {
        pasitoApasito.setActividad(activ);
        return "actividad";
    }

    public String borrarAct(Actividad activ) {
        
        //Buscar a todos los usuarios que participen en esa actividad
        List<Usuario> usuarios = ejbUSR.getUsuarios();
           
        List<Informe> informes = ejbINF.getInformes();
        for (Informe x : informes) {
            if (x.getCodActividad().getCodigoActividad().equals(activ.getCodigoActividad())) {
                ejbINF.eliminarInforme(x);
            }
        }
        
        List<SolicitudEntrada> solicitudesAll = ejbSOL.listaSolicitudes();
        for (SolicitudEntrada y : solicitudesAll) {
            if (y.getCodActividad().getCodigoActividad().equals(activ.getCodigoActividad())) {
                ejbSOL.borrarSolicitud(y);
            }
        }
        
        for (Usuario x : usuarios) {
            Usuario aux = ejbUSR.buscarUsuario(x.getEmail());
            List<Actividad> res = aux.getParticipaEnAct();
            res.remove(activ);
            aux.setParticipaEnAct(res);

            if (aux instanceof Profesor && activ instanceof Formativa) {
                List<Formativa> forms = ((Profesor) aux).getCoordinaForm();
                forms.remove(((Formativa) activ));
                ((Profesor) aux).setCoordinaForm(forms);
            }
            
            List<Actividad> coordinadas = aux.getActCoordinadas();
            coordinadas.remove(activ);
            aux.setActCoordinadas(coordinadas);
            
            List<SolicitudEntrada> solicitudes = aux.getSolicitudes();
            for (SolicitudEntrada y : solicitudes) {
                if (y.getCodActividad().getCodigoActividad().equals(activ.getCodigoActividad())) {
                    solicitudes.remove(y);
                }
            }
            aux.setSolicitudes(solicitudes);
            ejbUSR.actualizarUsuario(aux);
        }

        ejbACT.borrarActividad(activ);
        return "listaActividades";
    }

    public String getOrg() {
        return org;
    }

    public void setOrg(String org) {
        this.org = org;
    }

    public Integer getNumHoras() {

        return numHoras;
    }

    public void setNumHoras(String a) {
        this.numHoras = Integer.parseInt(a);
    }

    public String getNombreActividad() {
        return nombreActividad;
    }

    public String getDescripcionActividad() {
        return descripcionActividad;
    }

    public String getTipo() {
        return tipo;
    }

    public void setNombreActividad(String nombreActividad) {
        this.nombreActividad = nombreActividad;
    }

    public void setDescripcionActividad(String descripcionActividad) {
        this.descripcionActividad = descripcionActividad;
    }

    public void setTipo(String tipo) {
        this.tipo = tipo;
    }

    public ArrayList<Actividad> getActividades() {
        return ejbACT.listaActividades();
    }

    public ArrayList<Actividad> getActividadesDisponibles() {
        //Coger la lista del alumno
        Object entidad = control.getEntidad();

        List<Actividad> actividadesEntidad = new ArrayList<>();

        if (entidad instanceof Profesor) {
            Profesor prof = (Profesor) entidad;
            actividadesEntidad.addAll(prof.getCoordinaForm());
            actividadesEntidad.addAll(prof.getParticipaEnAct());
        } else if (entidad instanceof Alumno) {
            Alumno alu = (Alumno) entidad;
            actividadesEntidad.addAll(alu.getParticipaEnAct());
        }

        ArrayList<Actividad> actividadesTotales = ejbACT.listaActividades();

        if (!actividadesEntidad.isEmpty()) {
            for (Actividad aux : actividadesEntidad) {
                actividadesTotales.remove(aux);
            }
        }
        return actividadesTotales;
    }

//Para las ongs que tienen que estar pondremos un selector de todas las que hay.
    public String seleccionDeOng() {
        ONG aux = null;
        for (ONG o : perfOng.getONGs()) {
            if (org.equals(o.getNombreOrg())) {
                aux = o;
            }
        }
        Usuario usraux = (Usuario) control.getEntidad();
        if (tipo.equals("V")) {
            Voluntariado vol = new Voluntariado();
            vol.setCoordinador(usraux);
            vol.setDescripcion(descripcionActividad);
            vol.setNIFONG(aux);
            vol.setNombreActividad(nombreActividad);
            vol.setNumeroDeCreditos(creditos);
            vol.setNumHoras(numHoras);
            ejbACT.crearActividad(vol);
        } else if (tipo.equals("F")) {
            Formativa form = new Formativa();
            form.setCoordinador(usraux);
            form.setDescripcion(descripcionActividad);
            form.setNIFONG(aux);
            form.setNombreActividad(nombreActividad);
            form.setRamaDeEstudio(rama);
            form.setNumHoras(numHoras);
            ejbACT.crearActividad(form);

        }
        return "listaActividades";
    }

    public void setNumHoras(Integer numHoras) {
        this.numHoras = numHoras;
    }

    public String getRama() {
        return rama;
    }

    public void setRama(String rama) {
        this.rama = rama;
    }

    public Integer getCreditos() {
        return creditos;
    }

    public void setCreditos(Integer creditos) {
        this.creditos = creditos;
    }

    @Override
    public int hashCode() {
        int hash = 7;
        hash = 59 * hash + Objects.hashCode(this.pasitoApasito);
        hash = 59 * hash + Objects.hashCode(this.perfOng);
        hash = 59 * hash + Objects.hashCode(this.control);
        hash = 59 * hash + Objects.hashCode(this.log);
        hash = 59 * hash + Objects.hashCode(this.nombreActividad);
        hash = 59 * hash + Objects.hashCode(this.numHoras);
        hash = 59 * hash + Objects.hashCode(this.descripcionActividad);
        hash = 59 * hash + Objects.hashCode(this.tipo);
        hash = 59 * hash + Objects.hashCode(this.rama);
        hash = 59 * hash + Objects.hashCode(this.creditos);
        hash = 59 * hash + Objects.hashCode(this.org);
        return hash;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        final crearTarea other = (crearTarea) obj;
        if (!Objects.equals(this.nombreActividad, other.nombreActividad)) {
            return false;
        }
        if (!Objects.equals(this.descripcionActividad, other.descripcionActividad)) {
            return false;
        }
        if (!Objects.equals(this.tipo, other.tipo)) {
            return false;
        }
        if (!Objects.equals(this.rama, other.rama)) {
            return false;
        }
        if (!Objects.equals(this.org, other.org)) {
            return false;
        }
        if (!Objects.equals(this.pasitoApasito, other.pasitoApasito)) {
            return false;
        }
        if (!Objects.equals(this.perfOng, other.perfOng)) {
            return false;
        }
        if (!Objects.equals(this.control, other.control)) {
            return false;
        }
        if (!Objects.equals(this.log, other.log)) {
            return false;
        }
        if (!Objects.equals(this.numHoras, other.numHoras)) {
            return false;
        }
        if (!Objects.equals(this.creditos, other.creditos)) {
            return false;
        }
        return true;
    }

}
