package backingBeans;

//Listo 

import ejb.EJB_UsuarioLocal;
import java.io.Serializable;
import java.util.List;
import java.util.Objects;
import javax.ejb.EJB;
import javax.enterprise.context.RequestScoped;
import javax.inject.Named;
import javax.faces.application.FacesMessage;
import javax.faces.context.FacesContext;
import javax.inject.Inject;
import jpa.Actividad;
import jpa.Alumno;
import jpa.Profesor;
import jpa.SolicitudEntrada;
import jpa.Usuario;

/**
 *
 * @author francis
 */
@Named(value = "login")
@RequestScoped
public class Login implements Serializable {

    /*Atributos para iniciar sesion */
    private String email;
    private String contrasenia;

    /*Atributos para registro */
    private String nombrereg;
    private String apellidosreg;
    private String emailreg;
    private String DNIreg;
    private String passreg;
    private String repPassreg;
    /*------------------------*/

    @Inject
    private ControlAutorizacion ctrl;

    @EJB
    private EJB_UsuarioLocal ejbUser;

    public Login() {

    }

    public ControlAutorizacion getCtrl() {
        return ctrl;
    }

    public void setCtrl(ControlAutorizacion ctrl) {
        this.ctrl = ctrl;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getNombrereg() {
        return nombrereg;
    }

    public void setNombrereg(String nombrereg) {
        this.nombrereg = nombrereg;
    }

    public String getApellidosreg() {
        return apellidosreg;
    }

    public void setApellidosreg(String apellidosreg) {
        this.apellidosreg = apellidosreg;
    }

    public String getEmailreg() {
        return emailreg;
    }

    public void setEmailreg(String emailreg) {
        this.emailreg = emailreg;
    }

    public String getDNIreg() {
        return DNIreg;
    }

    public void setDNIreg(String DNIreg) {
        this.DNIreg = DNIreg;
    }

    public String getPassreg() {
        return passreg;
    }

    public void setPassreg(String passreg) {
        this.passreg = passreg;
    }

    public String getRepPassreg() {
        return repPassreg;
    }

    public void setRepPassreg(String repPassreg) {
        this.repPassreg = repPassreg;
    }

    public String getContrasenia() {
        return contrasenia;
    }

    public void setUsuario(String usuario) {
        this.email = usuario;
    }

    public void setContrasenia(String contrasenia) {
        this.contrasenia = contrasenia;
    }

    public String autenticar() { 
        FacesContext ctx = FacesContext.getCurrentInstance();
        if (this.email.equals("") || this.contrasenia.equals("")) {
            ctx.addMessage(null, new FacesMessage(FacesMessage.SEVERITY_ERROR, "Error, no hay usuario o contraseña", "Error, no hay usuario o contraseña"));
            return null;
        }
        Object user = ejbUser.buscarUsuario(email);
         
        if (user == null || !((Usuario) user).getContrasenya().equals(contrasenia)) {
            return "login";
        }
        ctrl.setEntidad(user);
        return "dashboard";
    }

    public String registrar() {
        FacesContext.getCurrentInstance();
        if (DNIreg.equals("") || apellidosreg.equals("") | nombrereg.equals("") | emailreg.equals("") | passreg.equals("")) {
            FacesMessage fm = new FacesMessage("Hay campos nulos");
            FacesContext.getCurrentInstance().addMessage("Sistema: ", fm);
            return null;
        }
        if (!this.passreg.equals(this.repPassreg)) {
            FacesMessage fm = new FacesMessage("Las contraseñas no coinciden");
            FacesContext.getCurrentInstance().addMessage("Sistema: ", fm);
            return null;
        }
        Alumno alumno = new Alumno();
        alumno.setDNI(DNIreg);
        alumno.setNombre(nombrereg);
        alumno.setApellidos(apellidosreg);
        alumno.setEmail(emailreg);
        alumno.setContrasenya(passreg);
        if(ejbUser.crearAlumno(alumno) == -1){
            FacesMessage fm = new FacesMessage("Ya hay una cuenta así");
            FacesContext.getCurrentInstance().addMessage("Sistema: ", fm);
            return null;
        }

        return "login";
    }

    
    @Override
    public int hashCode() {
        int hash = 5;
        hash = 53 * hash + Objects.hashCode(this.email);
        hash = 53 * hash + Objects.hashCode(this.contrasenia);
        hash = 53 * hash + Objects.hashCode(this.nombrereg);
        hash = 53 * hash + Objects.hashCode(this.apellidosreg);
        hash = 53 * hash + Objects.hashCode(this.emailreg);
        hash = 53 * hash + Objects.hashCode(this.DNIreg);
        hash = 53 * hash + Objects.hashCode(this.passreg);
        hash = 53 * hash + Objects.hashCode(this.repPassreg);
        hash = 53 * hash + Objects.hashCode(this.ctrl);
        return hash;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        final Login other = (Login) obj;
        if (!Objects.equals(this.email, other.email)) {
            return false;
        }
        if (!Objects.equals(this.contrasenia, other.contrasenia)) {
            return false;
        }
        if (!Objects.equals(this.nombrereg, other.nombrereg)) {
            return false;
        }
        if (!Objects.equals(this.apellidosreg, other.apellidosreg)) {
            return false;
        }
        if (!Objects.equals(this.emailreg, other.emailreg)) {
            return false;
        }
        if (!Objects.equals(this.DNIreg, other.DNIreg)) {
            return false;
        }
        if (!Objects.equals(this.passreg, other.passreg)) {
            return false;
        }
        if (!Objects.equals(this.repPassreg, other.repPassreg)) {
            return false;
        }
        if (!Objects.equals(this.ctrl, other.ctrl)) {
            return false;
        }
        return true;
    }

}
