package backingBeans;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

import ejb.EJB_ActividadLocal;
import ejb.EJB_SolicitudEntradaLocal;
import ejb.EJB_UsuarioLocal;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Objects;
import javax.ejb.EJB;
import javax.enterprise.context.RequestScoped;
import javax.inject.Inject;
import javax.inject.Named;
import jpa.Actividad;
import jpa.Formativa;
import jpa.SolicitudEntrada;
import jpa.Usuario;
import jpa.Profesor;

@Named(value="unirseTarea")
@RequestScoped
public class UnirseTarea implements Serializable {

    @Inject
    private ControlAutorizacion control;
    
    @Inject
    private Login login;
    
    @EJB
    private EJB_SolicitudEntradaLocal ejbSol;

    @EJB
    private EJB_UsuarioLocal ejbUser;
    
    @EJB
    private EJB_ActividadLocal ejbAct;
    

    //private static ArrayList<SolicitudEntrada> solicitudes = new ArrayList<>();
    //private static Integer codigos = 1;

    public UnirseTarea() {

    }

    public Login getLogin() {
        return login;
    }

    public void setLogin(Login login) {
        this.login = login;
    }
    
    public ControlAutorizacion getControl() {
        return control;
    }

    public void setControl(ControlAutorizacion control) {
        this.control = control;
    }

    public ArrayList<SolicitudEntrada> getSolicitudes() {
        
        ArrayList<SolicitudEntrada> res = new ArrayList<>();
        
        for(SolicitudEntrada x: ejbSol.listaSolicitudes()){
            if(x.getCodActividad().getCoordinador().equals(control.getUser())){
                res.add(x);
            }  
        }
        
        return res;
        //return ejbSol.listaSolicitudes();
    }



    public String crearSolicitud(Actividad act) {
        SolicitudEntrada solicitud = new SolicitudEntrada();
        solicitud.setCodActividad(act);
        
        Object aux = control.getEntidad();
                    
        solicitud.setCodUsuario( (Usuario) aux );
        solicitud.setFechaDeSolicitud(new Date());
        
        ejbSol.crearSolicitud(solicitud);
        
        return "listaActividades";
       

    }
    
    public String aceptarSolicitud(SolicitudEntrada soli){
        List<Usuario> lisaux = soli.getCodActividad().getUsuarioPart();
        lisaux.add(soli.getCodUsuario());
        soli.getCodActividad().setUsuarioPart(lisaux);
        //login.setActividad(soli);
        // Actualizacion de usuario
        Usuario user = ejbUser.buscarUsuario(soli.getCodUsuario().getEmail());
        List<Actividad> laux = user.getParticipaEnAct();
        laux.add(soli.getCodActividad());
        user.setParticipaEnAct(laux);
        ejbUser.actualizarUsuario(user);
        
        // Actualizacion de actividad        
        Actividad act = ejbAct.buscarActividad(soli.getCodActividad().getCodigoActividad());
        List<Usuario> l = act.getUsuarioPart();
        l.add(user);
        act.setUsuarioPart(l);
        ejbAct.actualizarActividad(act);    
        ejbUser.actualizarUsuario(user);
        ejbSol.borrarSolicitud(soli);
        return "dashboard";
    }
    
    public String borrarSolicitud(SolicitudEntrada soli){
        ejbSol.borrarSolicitud(soli);
        return "dashboard";
    }
    
    public String supervisaActividad(Formativa act){
        //Actualizar profesor
        Profesor pr = (Profesor) control.getEntidad();
        List<Formativa> laux = pr.getCoordinaForm();
        List<Actividad> laux2 = pr.getActCoordinadas();
        laux.add(act);
        laux2.add(act);
        pr.setCoordinaForm(laux);
        pr.setActCoordinadas(laux2);
        ejbUser.actualizarUsuario(pr); 
        
        control.setEntidad(pr);
        //Actualizar actividad
        List<Profesor> lprof = act.getCoordProf();
        lprof.add(pr);
        act.setCoordProf(lprof);
        ejbAct.actualizarActividad(act);
        
        
        return "dashboard";
    }

    @Override
    public int hashCode() {
        int hash = 3;
        hash = 29 * hash + Objects.hashCode(this.control);
        hash = 29 * hash + Objects.hashCode(this.login);
        return hash;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        final UnirseTarea other = (UnirseTarea) obj;
        if (!Objects.equals(this.control, other.control)) {
            return false;
        }
        if (!Objects.equals(this.login, other.login)) {
            return false;
        }
        return true;
    }

    
    
}
