package backingBeans;

import ejb.EJB_ActividadLocal;
import ejb.EJB_InformeLocal;
import ejb.EJB_UsuarioLocal;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Objects;
import javax.ejb.EJB;
import javax.enterprise.context.RequestScoped;
import javax.enterprise.context.SessionScoped;
import javax.inject.Inject;
import javax.inject.Named;
import jpa.Actividad;
import jpa.Informe;
import jpa.ONG;
import jpa.Usuario;

@Named
@SessionScoped
public class addRating implements Serializable {

    @Inject
    private ControlAutorizacion ctrl;
    
    @EJB
    EJB_InformeLocal ejbInf;
    
    @EJB
    EJB_UsuarioLocal ejbUSR;
    
    @EJB
    EJB_ActividadLocal ejbACT;

    private ONG ong;
    private Actividad act;
    private String mensaje;
    private String punta;
    private String puntu;

    public addRating() {
    }

    public ONG getOngObject() {
        return ong;
    }
    
    public Actividad getActividad() {
        return act;
    }

    public void setAct(Actividad act) {
        this.act = act;
    }

    public void setOng(ONG ong) {
        this.ong = ong;
    }
    
    
    public ControlAutorizacion getCtrl() {
        return ctrl;
    }

    public void setCtrl(ControlAutorizacion ctrl) {
        this.ctrl = ctrl;
    }

    public String enviarmsg() {
        Usuario user = (Usuario) ctrl.getEntidad();
        Informe inf = new Informe();
        inf.setCodActividad(act);
        inf.setCodUsuario(user);
        inf.setContenidoInforme(mensaje);
        inf.setFechaInforme((new Date()));
        inf.setValoracionActividad(punta);
        inf.setValoracionUsuario(mensaje);

        ejbInf.insertarInforme(inf);
        List<Actividad> susAct = user.getParticipaEnAct();
        susAct.remove(act);
        List<Usuario> participantes = act.getUsuarioPart();
        participantes.remove(user);
        act.setUsuarioPart(participantes);
        ejbACT.actualizarActividad(act);
        user.setActCoordinadas(susAct);
        ejbUSR.actualizarUsuario(user);

        return "dashboard";
    }

    public ArrayList<Informe> getInformes() {
        return ejbInf.getInformes();
    }
    /*
    public void setInformes(ArrayList<Informe> informes) {
        addRating.informes = informes;
    }
    */
    public String gotoValora(Actividad res) {
        act = res;
        System.out.println("" + act.getNIFONG().getNombreOrg() + act.getNombreActividad());
        ong = res.getNIFONG();
        return "puntuarActividad";
    }

    public String getOng() {
        return ong.getNombreOrg();
    }
    
    public String getAct() {
        return act.getNombreActividad();
    }

    public String getMensaje() {
        return mensaje;
    }

    public void setMensaje(String mensaje) {
        this.mensaje = mensaje;
    }

    public String getPunta() {
        return punta;
    }

    public void setPunta(String punta) {
        this.punta = punta;
    }

    public String getPuntu() {
        return puntu;
    }

    public void setPuntu(String puntu) {
        this.puntu = puntu;
    }

    @Override
    public int hashCode() {
        int hash = 3;
        hash = 47 * hash + Objects.hashCode(this.ctrl);
        hash = 47 * hash + Objects.hashCode(this.ong);
        hash = 47 * hash + Objects.hashCode(this.act);
        hash = 47 * hash + Objects.hashCode(this.mensaje);
        hash = 47 * hash + Objects.hashCode(this.punta);
        hash = 47 * hash + Objects.hashCode(this.puntu);
        return hash;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        final addRating other = (addRating) obj;
        if (!Objects.equals(this.mensaje, other.mensaje)) {
            return false;
        }
        if (!Objects.equals(this.punta, other.punta)) {
            return false;
        }
        if (!Objects.equals(this.puntu, other.puntu)) {
            return false;
        }
        if (!Objects.equals(this.ctrl, other.ctrl)) {
            return false;
        }
        if (!Objects.equals(this.ong, other.ong)) {
            return false;
        }
        if (!Objects.equals(this.act, other.act)) {
            return false;
        }
        return true;
    }
    
    

}
