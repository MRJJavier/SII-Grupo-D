/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ejb;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;
import jpa.Actividad;
import jpa.Formativa;
import jpa.ONG;
import jpa.Usuario;
import jpa.Voluntariado;

/**
 *
 * @author Sergio
 */
@Stateless
public class EJB_Actividad implements EJB_ActividadLocal {

    @PersistenceContext(unitName = "JPAPU")
    private EntityManager em;

    @Override
    public ArrayList<Actividad> listaActividades() {
        TypedQuery<Actividad> query = em.createNamedQuery("Actividad.findAll", Actividad.class);

        List<Actividad> lista = query.getResultList();
        if (lista == null) {
            ArrayList<Actividad> aux = new ArrayList<>();
            return aux;
        } else {
            ArrayList<Actividad> aux = new ArrayList<>();
            for (Actividad o : lista) {
                aux.add(o);
            }
            return aux;
        }
    }

    @Override
    public void crearActividad(Actividad act) {
        em.persist(act);
    }

    @Override
    public void borrarActividad(Actividad act) {

        /*
        Actividad aux = em.find(act.getClass(), act.getCodigoActividad());
        em.remove(aux);
        */
        
        if (act instanceof Formativa) {
            Actividad aux = em.find(Formativa.class, act.getCodigoActividad());
            em.remove((Formativa) aux);
        } else if (act instanceof Voluntariado) {            
            Actividad aux = em.find(Voluntariado.class, act.getCodigoActividad());
            em.remove((Voluntariado) aux);
        }

    }

    @Override
    public Integer numeroParticipantesAct(Actividad act) {
        return act.getUsuarioPart().size();
    }

    @Override
    public void actualizarActividad(Actividad activ) {

        if (activ instanceof Voluntariado) {
            Voluntariado v = (Voluntariado) activ;
            em.merge(v);
        } else if (activ instanceof Formativa) {
            Formativa f = (Formativa) activ;
            em.merge(f);
        }
    }

    @Override
    public Actividad buscarActividad(Long codigo) {
        Formativa f = em.find(Formativa.class, codigo);
        if (f != null) {
            return f;
        }
        Voluntariado v = em.find(Voluntariado.class, codigo);
        if (v != null) {
            return v;
        }
        return null;
    }
}
