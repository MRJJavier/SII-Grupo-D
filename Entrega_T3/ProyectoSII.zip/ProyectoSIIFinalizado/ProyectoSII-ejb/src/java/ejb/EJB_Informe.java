/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ejb;

import java.util.ArrayList;
import java.util.List;
import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;
import jpa.Actividad;
import jpa.Informe;

/**
 *
 * @author Sergio
 */
@Stateless
public class EJB_Informe implements EJB_InformeLocal{
    @PersistenceContext(unitName = "JPAPU")
    private EntityManager em;
    
    @Override
    public ArrayList<Informe> getInformes(){
        TypedQuery<Informe> query = em.createNamedQuery("Informe.findAll", Informe.class);
        
        
        
        List<Informe> lista = query.getResultList();
        if(lista== null){
            ArrayList<Informe> aux= new ArrayList<>();
            return aux;
        }else{
            ArrayList<Informe> aux= new ArrayList<>();
            for(Informe o:lista){
                aux.add(o);
            }
            return aux;
        }
    }
    
    @Override
    public void insertarInforme(Informe inf){
        em.persist(inf);
    }
    
    @Override
    public void eliminarInforme(Informe inf){
        em.remove(em.merge(inf));
    }
}
