/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ejb;

import java.util.ArrayList;
import jpa.Actividad;

/**
 *
 * @author Sergio
 */
public interface EJB_ActividadLocal {
    public ArrayList<Actividad> listaActividades();
    public void borrarActividad(Actividad act);
    public void crearActividad(Actividad act);
    public Integer numeroParticipantesAct(Actividad act);
    public void actualizarActividad(Actividad activ);
    public Actividad buscarActividad(Long codigo);
}
