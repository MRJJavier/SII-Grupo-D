/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ejb;

import java.util.ArrayList;
import java.util.List;
import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import javax.persistence.TypedQuery;
import jpa.Alumno;
import jpa.ONG;
import jpa.Profesor;
import jpa.Usuario;

/**
 *
 * @author Rafael
 */
@Stateless
public class EJB_Usuario implements EJB_UsuarioLocal {

    @PersistenceContext(unitName = "JPAPU")
    private EntityManager em;

    @Override
    public Usuario buscarUsuario(String email) {
        Alumno alumnoAux = em.find(Alumno.class, email);
        if (alumnoAux != null) {
            return alumnoAux;
        }
        Profesor profesorAux = em.find(Profesor.class, email);
        if (profesorAux != null) {
            return profesorAux;
        }
        Usuario userAux = em.find(Usuario.class, email);
        if (userAux != null) {
            return userAux;
        }
        return null;
    }

    @Override
    public List<Usuario> getUsuarios() {
        TypedQuery<Usuario> query = em.createNamedQuery("Usuario.findAll", Usuario.class);
        
        List<Usuario> lista = query.getResultList();
        
        return lista;      
        
    }

    @Override
    public Integer crearAlumno(Alumno alumno) { //Devuelve -1 si ya hay un alumno igual (error) y 0 si todo ha ido bien
        if (em.find(Alumno.class, alumno.getEmail()) != null) {
            return -1;
        }
        em.persist(alumno);
        return 0;
    }

    @Override
    public Integer borrarUsuario() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    // Add business logic below. (Right-click in editor and choose
    // "Insert Code > Add Business Method")
    @Override
    public void actualizarUsuario(Usuario entidad) {

        if (entidad instanceof Profesor) {
            Profesor prof = (Profesor) entidad;
            em.merge(prof);
        } else if (entidad instanceof Alumno) {
            Alumno alu = (Alumno) entidad;
            em.merge(alu);
        } else {
            Usuario user = (Usuario) entidad;
            em.merge(user);
        }

    }

}
