/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ejb;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;
import jpa.ONG;

/**
 *
 * @author Sergio
 */
@Stateless
public class EJB_ONG implements EJB_ONGLocal{
    @PersistenceContext(unitName = "JPAPU")
    private EntityManager em;
    
    @Override
    public ArrayList<ONG> listaONGs(){   
        
        
        
        TypedQuery<ONG> query = em.createNamedQuery("ONG.findAll", ONG.class);
        
        
        
        List<ONG> lista = query.getResultList();
        
        if(lista== null){
            ArrayList<ONG> aux= new ArrayList<>();
            return aux;
        }else{
            ArrayList<ONG> aux= new ArrayList<>();
            for(ONG o:lista){
                aux.add(o);
            }
            return aux;
        }
        
        
    }
    

    @Override
    public void borrarONG(ONG res){
       ONG aux = em.find(res.getClass(), res.getNIF());
       em.remove(aux);
    }
}
