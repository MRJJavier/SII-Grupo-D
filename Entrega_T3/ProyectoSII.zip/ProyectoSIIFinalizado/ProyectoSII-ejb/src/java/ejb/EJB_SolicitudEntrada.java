/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ejb;

import java.util.ArrayList;
import java.util.List;
import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import javax.persistence.TypedQuery;
import jpa.SolicitudEntrada;

/**
 *
 * @author Sergio
 */
@Stateless
public class EJB_SolicitudEntrada implements EJB_SolicitudEntradaLocal {

    @PersistenceContext(unitName = "JPAPU")
    private EntityManager em;

    @Override
    public ArrayList<SolicitudEntrada> listaSolicitudes() {
        TypedQuery<SolicitudEntrada> query = em.createNamedQuery("SolicitudEntrada.findAll", SolicitudEntrada.class);
        List<SolicitudEntrada> lista = query.getResultList();
        if (lista == null) {
            ArrayList<SolicitudEntrada> aux = new ArrayList<>();
            return aux;
        } else {
            ArrayList<SolicitudEntrada> aux = new ArrayList<>();
            for (SolicitudEntrada o : lista) {
                aux.add(o);
            }
            return aux;
        }
    }

    @Override
    public void crearSolicitud(SolicitudEntrada act) {
        
        ArrayList<SolicitudEntrada> aux = listaSolicitudes();
        
        boolean esta = false;
        
        for(SolicitudEntrada x : aux){
            if(x.getCodUsuario().getEmail().equals(act.getCodUsuario().getEmail()) 
                    &&
               x.getCodActividad().getCodigoActividad().equals(act.getCodActividad().getCodigoActividad()) ){
                esta = true;
                break;
            }
        }
        
        if (!esta)      
            em.persist(act);        
    }

    @Override
    public void borrarSolicitud(SolicitudEntrada act) {
        SolicitudEntrada aux = em.find(act.getClass(), act.getCodigoSolicitud());
        em.remove(aux);
    }
}
