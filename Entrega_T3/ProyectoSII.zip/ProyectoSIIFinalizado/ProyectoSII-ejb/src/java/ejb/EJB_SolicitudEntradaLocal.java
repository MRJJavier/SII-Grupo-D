/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ejb;

import java.util.ArrayList;
import jpa.SolicitudEntrada;

/**
 *
 * @author Sergio
 */
public interface EJB_SolicitudEntradaLocal {
    
    public ArrayList<SolicitudEntrada> listaSolicitudes();
    public void borrarSolicitud(SolicitudEntrada act);
    public void crearSolicitud(SolicitudEntrada act);
    
}
