/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ejb;

import java.util.List;
import javax.ejb.Local;
import jpa.Alumno;
import jpa.Profesor;
import jpa.Usuario;

/**
 *
 * @author Rafael
 */
@Local
public interface EJB_UsuarioLocal {
    Usuario buscarUsuario(String email);
    List<Usuario> getUsuarios();
    Integer crearAlumno(Alumno alumno);
    Integer borrarUsuario();
    void actualizarUsuario(Usuario entidad);
   
}
