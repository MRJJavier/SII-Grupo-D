package jpa;



/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
import java.io.Serializable;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Objects;
import javax.persistence.Column;
import javax.persistence.DiscriminatorColumn;
import javax.persistence.DiscriminatorType;
import javax.persistence.DiscriminatorValue;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Inheritance;
import javax.persistence.InheritanceType;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.ManyToMany;
import javax.persistence.NamedQuery;
import javax.persistence.OneToMany;

import javax.persistence.Temporal;
import javax.persistence.TemporalType;

/**
 * 
 * @author ps3aj
 */
@Entity
@Inheritance(strategy = InheritanceType.JOINED)
@DiscriminatorColumn(
    name="DiscrCOL",
    discriminatorType=DiscriminatorType.STRING
)
@DiscriminatorValue(value="U")
@NamedQuery(name="Usuario.findAll", query="SELECT u FROM Usuario u")
public class Usuario implements Serializable {
    private static final long serialVersionUID = 1L;
    
    @Id
    private String email;
    
    @Column(nullable = false)
    private String contrasenya; // HASH / SALT de la contrasenya
    
    @Column(nullable = false, unique = true)
    private String DNI;
    
    @Column(nullable = false)
    private String nombre;
    
    @Column(nullable = false)
    private String apellidos;
    
    @Temporal(TemporalType.DATE)
    private Date fechaNacimiento;
    
    private String competencias;
    
    private String profesion;
           
    private String telefono;
        
    private String direccion;
    
    @ManyToMany
    @JoinTable(name = "USUARIO_PART_ACT", joinColumns = { @JoinColumn(name = "usuario_fk") }, inverseJoinColumns = { @JoinColumn(name = "actividad_fk") })
    private List<Actividad> participaEnAct = new ArrayList<>();
    
    @Column
    private String disponibilidad;
    
    @JoinColumn
    @OneToMany( mappedBy = "codUsuario")
    private List<SolicitudEntrada> solicitudes;
    
    @JoinTable(name = "USER_ONG", joinColumns = { @JoinColumn(name = "usuario_fk") }, inverseJoinColumns = { @JoinColumn(name = "ONG_fk") })
    private List<ONG> perteneceAONG;
    
    @OneToMany( mappedBy = "coordinador")
    private List<Actividad> actCoordinadas = new ArrayList<>();
    
    
    public Usuario() { }
    

    public List<Actividad> getParticipaEnAct() {
        return participaEnAct;
    }

    public void setParticipaEnAct(List<Actividad> participaEnAct) {
        this.participaEnAct = participaEnAct;
    }

    public List<SolicitudEntrada> getSolicitudes() {
        return solicitudes;
    }

    public void setSolicitudes(List<SolicitudEntrada> solicitudes) {
        this.solicitudes = solicitudes;
    }

    public List<Actividad> getActCoordinadas() {
        return actCoordinadas;
    }

    public void setActCoordinadas(List<Actividad> actCoordinadas) {
        this.actCoordinadas = actCoordinadas;
    }

    
    // getters y setters

    public String getDisponibilidad() {
        return disponibilidad;
    }

    public void setDisponibilidad(String disponibilidad) {
        this.disponibilidad = disponibilidad;
    }
    
    
    public String getDNI() {
        return DNI;
    }

    public void setDNI(String DNI) {
        this.DNI = DNI;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getApellidos() {
        return apellidos;
    }

    public void setApellidos(String apellidos) {
        this.apellidos = apellidos;
    }

    public String getContrasenya() {
        return contrasenya;
    }

    public void setContrasenya(String contrasenya) {
        this.contrasenya = contrasenya;
    }
    
    public Date getFechaNacimiento() {
        return fechaNacimiento;
    }

    public void setFechaNacimiento(Date fechaNacimiento) {
        this.fechaNacimiento = fechaNacimiento;
    }

    public String getCompetencias() {
        return competencias;
    }

    public void setCompetencias(String competencias) {
        this.competencias = competencias;
    }

    public String getProfesion() {
        return profesion;
    }

    public void setProfesion(String profesion) {
        this.profesion = profesion;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getTelefono() {
        return telefono;
    }

    public void setTelefono(String telefono) {
        this.telefono = telefono;
    }

    public String getDireccion() {
        return direccion;
    }

    public void setDireccion(String direccion) {
        this.direccion = direccion;
    }

    public List<ONG> getPerteneceAONG() {
        return perteneceAONG;
    }

    public void setPerteneceAONG(List<ONG> perteneceAONG) {
        this.perteneceAONG = perteneceAONG;
    }
    
    //hashcode y equals
    @Override
    public int hashCode() {
        int hash = 7;
        hash = 73 * hash + Objects.hashCode(this.DNI);
        hash = 73 * hash + Objects.hashCode(this.nombre);
        hash = 73 * hash + Objects.hashCode(this.apellidos);
        hash = 73 * hash + Objects.hashCode(this.contrasenya);
        hash = 73 * hash + Objects.hashCode(this.fechaNacimiento);
        hash = 73 * hash + Objects.hashCode(this.competencias);
        hash = 73 * hash + Objects.hashCode(this.profesion);
        hash = 73 * hash + Objects.hashCode(this.email);
        hash = 73 * hash + Objects.hashCode(this.telefono);
        hash = 73 * hash + Objects.hashCode(this.direccion);
        hash = 73 * hash + Objects.hashCode(this.perteneceAONG);
        return hash;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        final Usuario other = (Usuario) obj;
        if (!Objects.equals(this.DNI, other.DNI)) {
            return false;
        }
        if (!Objects.equals(this.nombre, other.nombre)) {
            return false;
        }
        if (!Objects.equals(this.apellidos, other.apellidos)) {
            return false;
        }
        if (!Objects.equals(this.contrasenya, other.contrasenya)) {
            return false;
        }
        if (!Objects.equals(this.competencias, other.competencias)) {
            return false;
        }
        if (!Objects.equals(this.profesion, other.profesion)) {
            return false;
        }
        if (!Objects.equals(this.email, other.email)) {
            return false;
        }
        if (!Objects.equals(this.telefono, other.telefono)) {
            return false;
        }
        if (!Objects.equals(this.direccion, other.direccion)) {
            return false;
        }
        if (!Objects.equals(this.fechaNacimiento, other.fechaNacimiento)) {
            return false;
        }
        if (!Objects.equals(this.perteneceAONG, other.perteneceAONG)) {
            return false;
        }
        return true;
    }

    
    
    
}
