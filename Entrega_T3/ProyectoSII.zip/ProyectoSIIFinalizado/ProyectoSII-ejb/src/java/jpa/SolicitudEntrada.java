package jpa;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
import java.io.Serializable;
import java.util.Date;
import javax.persistence.*;

@Entity
@NamedQuery(name="SolicitudEntrada.findAll", query="SELECT s FROM SolicitudEntrada s")
public class SolicitudEntrada implements Serializable {
    private static final long serialVersionUID = 1L;
    
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private Integer codigoSolicitud;
    
    @ManyToOne(fetch = FetchType.LAZY)
    private Usuario codUsuario;
    
    @ManyToOne
    private Actividad codActividad;
    
    @Column(nullable = false)
    @Temporal(TemporalType.DATE)
    private Date fechaDeSolicitud;

    //getters y setters

    public void setCodigoSolicitud(Integer codigoSolicitud) {
        this.codigoSolicitud = codigoSolicitud;
    }
       
    public Date getFechaDeSolicitud() {
        return fechaDeSolicitud;
    }

    public void setFechaDeSolicitud(Date fechaDeSolicitud) {
        this.fechaDeSolicitud = fechaDeSolicitud;
    }

    public Usuario getCodUsuario() {
        return codUsuario;
    }

    public void setCodUsuario(Usuario codUsuario) {
        this.codUsuario = codUsuario;
    }


    public Actividad getCodActividad() {
        return codActividad;
    }

    public void setCodActividad(Actividad codActividad) {
        this.codActividad = codActividad;
    }

    public Integer getCodigoSolicitud() {
        return codigoSolicitud;
    } 
    
}
